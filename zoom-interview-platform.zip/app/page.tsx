import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Star, Users, Clock, Award, MessageSquare, Play } from "lucide-react"

export default function LandingPage() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100">
      {/* Header */}
      <header className="container mx-auto px-4 py-6">
        <nav className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <div className="h-8 w-8 bg-blue-600 rounded-lg flex items-center justify-center">
              <span className="text-white font-bold text-sm">AI</span>
            </div>
            <span className="text-xl font-bold text-gray-900">InterviewPro</span>
          </div>
          <div className="hidden md:flex items-center space-x-6">
            <Link href="#features" className="text-gray-600 hover:text-gray-900">
              Features
            </Link>
            <Link href="#demo" className="text-gray-600 hover:text-gray-900">
              Demo
            </Link>
            <Link href="#pricing" className="text-gray-600 hover:text-gray-900">
              Pricing
            </Link>
            <Button variant="outline">Sign In</Button>
            <Button>Get Started</Button>
          </div>
        </nav>
      </header>

      {/* Hero Section */}
      <section className="container mx-auto px-4 py-16 text-center">
        <div className="max-w-4xl mx-auto">
          <h1 className="text-5xl md:text-6xl font-bold text-gray-900 mb-6">
            AI-Powered Video Interviews with <span className="text-blue-600">Real-time Evaluation</span>
          </h1>
          <p className="text-xl text-gray-600 mb-8 max-w-2xl mx-auto">
            Conduct professional video interviews with automatic candidate evaluation, real-time scoring, and
            comprehensive analytics. Standardized, fair, and efficient hiring.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center mb-12">
            <Button size="lg" className="text-lg px-8 py-4">
              Start Free Trial
            </Button>
            <Link href="/interview-demo">
              <Button size="lg" variant="outline" className="text-lg px-8 py-4">
                Watch Live Interview
              </Button>
            </Link>
          </div>

          {/* Stats */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mt-16">
            <div className="text-center">
              <div className="text-3xl font-bold text-blue-600 mb-2">95%</div>
              <div className="text-gray-600">Accuracy Rate</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-blue-600 mb-2">50%</div>
              <div className="text-gray-600">Time Saved</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-blue-600 mb-2">1000+</div>
              <div className="text-gray-600">Companies Trust Us</div>
            </div>
          </div>
        </div>
      </section>

      {/* Live Interview Demo Section */}
      <section id="demo" className="container mx-auto px-4 py-16">
        <div className="max-w-6xl mx-auto text-center">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-6">See a Real Interview in Action</h2>
          <p className="text-xl text-gray-600 mb-8">
            Watch how our AI evaluates candidates in real-time during an actual interview session
          </p>

          {/* Demo Video Container */}
          <div className="relative bg-gray-900 rounded-2xl overflow-hidden shadow-2xl mb-12">
            <div className="aspect-video bg-gradient-to-br from-blue-800 to-purple-900 flex items-center justify-center">
              <div className="text-center">
                <div className="w-20 h-20 bg-blue-600 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Play className="w-8 h-8 text-white ml-1" />
                </div>
                <h3 className="text-white text-xl font-semibold mb-2">Live Interview Demo</h3>
                <p className="text-blue-200 mb-4">
                  Watch Sarah Johnson's complete interview with real-time AI evaluation
                </p>
                <Link href="/interview-demo">
                  <Button size="lg" className="bg-blue-600 hover:bg-blue-700">
                    Watch Interview
                  </Button>
                </Link>
              </div>
            </div>

            {/* Demo Features Overlay */}
            <div className="absolute top-4 left-4 bg-black/50 backdrop-blur-sm rounded-lg p-3">
              <div className="flex items-center space-x-2 text-white text-sm">
                <div className="w-2 h-2 bg-red-500 rounded-full animate-pulse"></div>
                <span>Live AI Evaluation</span>
              </div>
            </div>

            <div className="absolute top-4 right-4 bg-black/50 backdrop-blur-sm rounded-lg p-3">
              <div className="flex items-center space-x-2 text-white text-sm">
                <Star className="w-4 h-4 text-yellow-400" />
                <span>Real-time Scoring</span>
              </div>
            </div>

            <div className="absolute bottom-4 left-4 bg-black/50 backdrop-blur-sm rounded-lg p-3">
              <div className="flex items-center space-x-2 text-white text-sm">
                <MessageSquare className="w-4 h-4 text-green-400" />
                <span>Speech Recognition</span>
              </div>
            </div>
          </div>

          {/* Demo Features */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
            <div className="bg-white rounded-xl p-6 shadow-lg">
              <Users className="w-8 h-8 text-blue-600 mb-4 mx-auto" />
              <h3 className="font-semibold text-gray-900 mb-2">Real Interview</h3>
              <p className="text-gray-600 text-sm">Actual candidate interview with live responses</p>
            </div>
            <div className="bg-white rounded-xl p-6 shadow-lg">
              <Award className="w-8 h-8 text-green-600 mb-4 mx-auto" />
              <h3 className="font-semibold text-gray-900 mb-2">Auto Evaluation</h3>
              <p className="text-gray-600 text-sm">AI automatically scores responses in real-time</p>
            </div>
            <div className="bg-white rounded-xl p-6 shadow-lg">
              <MessageSquare className="w-8 h-8 text-purple-600 mb-4 mx-auto" />
              <h3 className="font-semibold text-gray-900 mb-2">Live Transcript</h3>
              <p className="text-gray-600 text-sm">Speech-to-text conversion with keyword analysis</p>
            </div>
            <div className="bg-white rounded-xl p-6 shadow-lg">
              <Clock className="w-8 h-8 text-orange-600 mb-4 mx-auto" />
              <h3 className="font-semibold text-gray-900 mb-2">Standardized Process</h3>
              <p className="text-gray-600 text-sm">Consistent evaluation for fair assessment</p>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section id="features" className="bg-white py-16">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">Powerful Features for Modern Hiring</h2>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              Everything you need to conduct professional interviews with AI-powered insights
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            <div className="p-6 rounded-xl border border-gray-200 hover:shadow-lg transition-shadow">
              <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center mb-4">
                <Users className="w-6 h-6 text-blue-600" />
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-2">HD Video Calls</h3>
              <p className="text-gray-600">
                Crystal clear video quality with professional audio for the best interview experience.
              </p>
            </div>

            <div className="p-6 rounded-xl border border-gray-200 hover:shadow-lg transition-shadow">
              <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center mb-4">
                <Award className="w-6 h-6 text-green-600" />
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-2">AI Evaluation</h3>
              <p className="text-gray-600">
                Automatic scoring based on communication skills, technical knowledge, and cultural fit.
              </p>
            </div>

            <div className="p-6 rounded-xl border border-gray-200 hover:shadow-lg transition-shadow">
              <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center mb-4">
                <Clock className="w-6 h-6 text-purple-600" />
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-2">Real-time Analytics</h3>
              <p className="text-gray-600">
                Live feedback and scoring during interviews with detailed post-interview reports.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="bg-blue-600 py-16">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">Ready to Transform Your Hiring Process?</h2>
          <p className="text-xl text-blue-100 mb-8 max-w-2xl mx-auto">
            Join thousands of companies using AI-powered interviews to find the best candidates faster.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button size="lg" variant="secondary" className="text-lg px-8 py-4">
              Start Free Trial
            </Button>
            <Link href="/interview-demo">
              <Button
                size="lg"
                variant="outline"
                className="text-lg px-8 py-4 text-white border-white hover:bg-white hover:text-blue-600"
              >
                Watch Live Demo
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-12">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div>
              <div className="flex items-center space-x-2 mb-4">
                <div className="h-8 w-8 bg-blue-600 rounded-lg flex items-center justify-center">
                  <span className="text-white font-bold text-sm">AI</span>
                </div>
                <span className="text-xl font-bold">InterviewPro</span>
              </div>
              <p className="text-gray-400">AI-powered video interviews for modern hiring teams.</p>
            </div>
            <div>
              <h3 className="font-semibold mb-4">Product</h3>
              <ul className="space-y-2 text-gray-400">
                <li>
                  <Link href="#" className="hover:text-white">
                    Features
                  </Link>
                </li>
                <li>
                  <Link href="#" className="hover:text-white">
                    Pricing
                  </Link>
                </li>
                <li>
                  <Link href="#" className="hover:text-white">
                    API
                  </Link>
                </li>
              </ul>
            </div>
            <div>
              <h3 className="font-semibold mb-4">Company</h3>
              <ul className="space-y-2 text-gray-400">
                <li>
                  <Link href="#" className="hover:text-white">
                    About
                  </Link>
                </li>
                <li>
                  <Link href="#" className="hover:text-white">
                    Blog
                  </Link>
                </li>
                <li>
                  <Link href="#" className="hover:text-white">
                    Careers
                  </Link>
                </li>
              </ul>
            </div>
            <div>
              <h3 className="font-semibold mb-4">Support</h3>
              <ul className="space-y-2 text-gray-400">
                <li>
                  <Link href="#" className="hover:text-white">
                    Help Center
                  </Link>
                </li>
                <li>
                  <Link href="#" className="hover:text-white">
                    Contact
                  </Link>
                </li>
                <li>
                  <Link href="#" className="hover:text-white">
                    Privacy
                  </Link>
                </li>
              </ul>
            </div>
          </div>
          <div className="border-t border-gray-800 mt-8 pt-8 text-center text-gray-400">
            <p>&copy; 2024 InterviewPro. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  )
}
