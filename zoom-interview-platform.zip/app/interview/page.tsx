"use client"

import { useState, useEffect, useRef } from "react"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import {
  Mic,
  MicOff,
  Video,
  VideoOff,
  Phone,
  Settings,
  Users,
  Star,
  Clock,
  MessageSquare,
  Award,
  ArrowLeft,
  Volume2,
} from "lucide-react"
import Link from "next/link"

const questions = [
  {
    id: 1,
    question: "Tell me about yourself and your background in software development.",
    category: "Introduction",
    expectedDuration: 120,
  },
  {
    id: 2,
    question: "Describe a challenging project you worked on and how you overcame the obstacles.",
    category: "Problem Solving",
    expectedDuration: 180,
  },
  {
    id: 3,
    question: "How do you stay updated with the latest technology trends?",
    category: "Learning & Growth",
    expectedDuration: 90,
  },
]

const evaluationCriteria = [
  { name: "Communication", weight: 25 },
  { name: "Technical Knowledge", weight: 30 },
  { name: "Problem Solving", weight: 25 },
  { name: "Cultural Fit", weight: 20 },
]

export default function InterviewPage() {
  const [currentQuestion, setCurrentQuestion] = useState(0)
  const [isRecording, setIsRecording] = useState(false)
  const [videoEnabled, setVideoEnabled] = useState(true)
  const [audioEnabled, setAudioEnabled] = useState(true)
  const [timeElapsed, setTimeElapsed] = useState(0)
  const [scores, setScores] = useState({
    communication: 0,
    technical: 0,
    problemSolving: 0,
    culturalFit: 0,
  })
  const [isListening, setIsListening] = useState(false)
  const [transcript, setTranscript] = useState("")
  const [overallScore, setOverallScore] = useState(0)
  const [speechSupported, setSpeechSupported] = useState(false)
  const recognitionRef = useRef<any>(null)

  // Check for speech recognition support
  useEffect(() => {
    if (typeof window !== "undefined") {
      const SpeechRecognition = window.SpeechRecognition || (window as any).webkitSpeechRecognition
      if (SpeechRecognition) {
        setSpeechSupported(true)
        recognitionRef.current = new SpeechRecognition()
        recognitionRef.current.continuous = true
        recognitionRef.current.interimResults = true
        recognitionRef.current.lang = "en-US"

        recognitionRef.current.onresult = (event: any) => {
          let finalTranscript = ""
          let interimTranscript = ""

          for (let i = event.resultIndex; i < event.results.length; i++) {
            const transcript = event.results[i][0].transcript
            if (event.results[i].isFinal) {
              finalTranscript += transcript + " "
            } else {
              interimTranscript += transcript
            }
          }

          setTranscript((prev) => prev + finalTranscript)
        }

        recognitionRef.current.onerror = (event: any) => {
          console.error("Speech recognition error:", event.error)
        }
      }
    }
  }, [])

  // Simulate real-time evaluation based on transcript
  useEffect(() => {
    if (transcript && isRecording) {
      // Analyze transcript for keywords and phrases
      const words = transcript.toLowerCase()

      // Communication scoring based on clarity and structure
      let commScore = 60
      if (words.includes("experience") || words.includes("background")) commScore += 10
      if (words.includes("project") || words.includes("work")) commScore += 10
      if (words.includes("team") || words.includes("collaborate")) commScore += 15
      if (words.length > 100) commScore += 5 // Length indicates elaboration

      // Technical scoring
      let techScore = 50
      const techKeywords = ["react", "javascript", "python", "node", "database", "api", "framework", "algorithm"]
      techKeywords.forEach((keyword) => {
        if (words.includes(keyword)) techScore += 8
      })

      // Problem solving scoring
      let problemScore = 55
      if (words.includes("challenge") || words.includes("problem")) problemScore += 15
      if (words.includes("solution") || words.includes("solve")) problemScore += 15
      if (words.includes("approach") || words.includes("method")) problemScore += 10

      // Cultural fit scoring
      let cultureScore = 65
      if (words.includes("learn") || words.includes("growth")) cultureScore += 10
      if (words.includes("team") || words.includes("collaboration")) cultureScore += 10
      if (words.includes("passion") || words.includes("excited")) cultureScore += 10

      const newScores = {
        communication: Math.min(100, commScore),
        technical: Math.min(100, techScore),
        problemSolving: Math.min(100, problemScore),
        culturalFit: Math.min(100, cultureScore),
      }

      setScores(newScores)

      // Calculate overall score
      const overall =
        newScores.communication * 0.25 +
        newScores.technical * 0.3 +
        newScores.problemSolving * 0.25 +
        newScores.culturalFit * 0.2
      setOverallScore(Math.round(overall))
    }
  }, [transcript, isRecording])

  // Timer
  useEffect(() => {
    if (isRecording) {
      const interval = setInterval(() => {
        setTimeElapsed((prev) => prev + 1)
      }, 1000)
      return () => clearInterval(interval)
    }
  }, [isRecording])

  const startRecording = () => {
    setIsRecording(true)
    setIsListening(true)
    setTimeElapsed(0)

    if (speechSupported && recognitionRef.current) {
      recognitionRef.current.start()
    }
  }

  const stopRecording = () => {
    setIsRecording(false)
    setIsListening(false)

    if (speechSupported && recognitionRef.current) {
      recognitionRef.current.stop()
    }
  }

  const nextQuestion = () => {
    if (currentQuestion < questions.length - 1) {
      setCurrentQuestion((prev) => prev + 1)
      setTranscript("")
      setTimeElapsed(0)
    }
  }

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60)
    const secs = seconds % 60
    return `${mins}:${secs.toString().padStart(2, "0")}`
  }

  return (
    <div className="min-h-screen bg-gray-100">
      {/* Header */}
      <header className="bg-white border-b border-gray-200 px-6 py-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <Link href="/">
              <Button variant="ghost" size="sm">
                <ArrowLeft className="w-4 h-4 mr-2" />
                Back to Home
              </Button>
            </Link>
            <div className="flex items-center space-x-2">
              <div className="h-8 w-8 bg-blue-600 rounded-lg flex items-center justify-center">
                <span className="text-white font-bold text-sm">AI</span>
              </div>
              <span className="text-xl font-bold text-gray-900">InterviewPro</span>
            </div>
          </div>
          <div className="flex items-center space-x-4">
            <Badge variant="secondary" className="bg-green-100 text-green-800">
              <div className="w-2 h-2 bg-green-500 rounded-full mr-2 animate-pulse"></div>
              Live Interview
            </Badge>
            {speechSupported && (
              <Badge variant="outline" className="bg-blue-50 text-blue-700">
                <Volume2 className="w-3 h-3 mr-1" />
                Speech Recognition Active
              </Badge>
            )}
            <div className="text-sm text-gray-600">
              Question {currentQuestion + 1} of {questions.length}
            </div>
          </div>
        </div>
      </header>

      <div className="flex h-[calc(100vh-80px)]">
        {/* Main Video Area */}
        <div className="flex-1 flex flex-col">
          {/* Video Container */}
          <div className="flex-1 bg-gray-900 relative">
            {/* Candidate Video (Main) */}
            <div className="w-full h-full bg-gradient-to-br from-blue-900 to-purple-900 flex items-center justify-center">
              {videoEnabled ? (
                <div className="text-center">
                  <div className="w-32 h-32 bg-blue-600 rounded-full flex items-center justify-center mx-auto mb-4">
                    <Users className="w-16 h-16 text-white" />
                  </div>
                  <p className="text-white text-lg">Candidate Video</p>
                  <p className="text-blue-200 text-sm">Camera Active</p>
                </div>
              ) : (
                <div className="text-center">
                  <VideoOff className="w-16 h-16 text-gray-400 mx-auto mb-4" />
                  <p className="text-gray-400">Camera Off</p>
                </div>
              )}
            </div>

            {/* Interviewer Video (Picture-in-Picture) */}
            <div className="absolute top-4 right-4 w-48 h-36 bg-gray-800 rounded-lg border-2 border-white shadow-lg">
              <div className="w-full h-full bg-gradient-to-br from-gray-700 to-gray-800 rounded-lg flex items-center justify-center">
                <div className="text-center">
                  <div className="w-12 h-12 bg-gray-600 rounded-full flex items-center justify-center mx-auto mb-2">
                    <Users className="w-6 h-6 text-white" />
                  </div>
                  <p className="text-white text-xs">Interviewer</p>
                </div>
              </div>
            </div>

            {/* Recording Indicator */}
            {isRecording && (
              <div className="absolute top-4 left-4 bg-red-600 text-white px-3 py-1 rounded-full text-sm flex items-center">
                <div className="w-2 h-2 bg-white rounded-full mr-2 animate-pulse"></div>
                REC {formatTime(timeElapsed)}
              </div>
            )}

            {/* Speech Recognition Indicator */}
            {isListening && (
              <div className="absolute top-16 left-4 bg-blue-600 text-white px-3 py-1 rounded-full text-sm flex items-center">
                <Volume2 className="w-3 h-3 mr-2" />
                Listening...
              </div>
            )}

            {/* AI Evaluation Overlay */}
            <div className="absolute bottom-4 left-4 bg-black/70 backdrop-blur-sm rounded-lg p-3 text-white">
              <div className="flex items-center space-x-2 mb-2">
                <Award className="w-4 h-4 text-yellow-400" />
                <span className="text-sm font-medium">AI Evaluation</span>
              </div>
              <div className="text-2xl font-bold text-green-400">{overallScore}%</div>
              <div className="text-xs text-gray-300">Real-time Score</div>
            </div>
          </div>

          {/* Controls */}
          <div className="bg-gray-800 px-6 py-4">
            <div className="flex items-center justify-center space-x-4">
              <Button
                variant={audioEnabled ? "secondary" : "destructive"}
                size="lg"
                onClick={() => setAudioEnabled(!audioEnabled)}
                className="rounded-full w-12 h-12 p-0"
              >
                {audioEnabled ? <Mic className="w-5 h-5" /> : <MicOff className="w-5 h-5" />}
              </Button>

              <Button
                variant={videoEnabled ? "secondary" : "destructive"}
                size="lg"
                onClick={() => setVideoEnabled(!videoEnabled)}
                className="rounded-full w-12 h-12 p-0"
              >
                {videoEnabled ? <Video className="w-5 h-5" /> : <VideoOff className="w-5 h-5" />}
              </Button>

              {!isRecording ? (
                <Button onClick={startRecording} className="bg-green-600 hover:bg-green-700 px-6" size="lg">
                  Start Answer
                </Button>
              ) : (
                <Button onClick={stopRecording} variant="destructive" className="px-6" size="lg">
                  Stop Answer
                </Button>
              )}

              <Button variant="secondary" size="lg" className="rounded-full w-12 h-12 p-0">
                <Settings className="w-5 h-5" />
              </Button>

              <Button variant="destructive" size="lg" className="rounded-full w-12 h-12 p-0">
                <Phone className="w-5 h-5" />
              </Button>
            </div>
          </div>
        </div>

        {/* Right Sidebar */}
        <div className="w-96 bg-white border-l border-gray-200 flex flex-col">
          {/* Current Question */}
          <div className="p-6 border-b border-gray-200">
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-semibold text-gray-900">Current Question</h3>
              <Badge variant="outline">{questions[currentQuestion].category}</Badge>
            </div>
            <p className="text-gray-700 mb-4">{questions[currentQuestion].question}</p>
            <div className="flex items-center text-sm text-gray-500">
              <Clock className="w-4 h-4 mr-1" />
              Expected: {questions[currentQuestion].expectedDuration}s | Elapsed: {formatTime(timeElapsed)}
            </div>
          </div>

          {/* Real-time Evaluation */}
          <div className="p-6 border-b border-gray-200">
            <h3 className="font-semibold text-gray-900 mb-4 flex items-center">
              <Star className="w-4 h-4 mr-2 text-yellow-500" />
              Live Evaluation
            </h3>
            <div className="space-y-3">
              {evaluationCriteria.map((criteria, index) => {
                const scoreKey = criteria.name.toLowerCase().replace(" ", "") as keyof typeof scores
                const score = Math.round(scores[scoreKey] || 0)
                return (
                  <div key={index}>
                    <div className="flex justify-between text-sm mb-1">
                      <span className="text-gray-600">{criteria.name}</span>
                      <span className="font-medium">{score}%</span>
                    </div>
                    <Progress value={score} className="h-2" />
                  </div>
                )
              })}
            </div>
            <div className="mt-4 p-3 bg-blue-50 rounded-lg">
              <div className="flex justify-between items-center">
                <span className="font-medium text-blue-900">Overall Score</span>
                <span className="text-2xl font-bold text-blue-600">{overallScore}%</span>
              </div>
            </div>
          </div>

          {/* Live Transcript */}
          <div className="flex-1 p-6">
            <h3 className="font-semibold text-gray-900 mb-4 flex items-center">
              <MessageSquare className="w-4 h-4 mr-2" />
              Live Transcript
              {isListening && <div className="ml-2 w-2 h-2 bg-red-500 rounded-full animate-pulse"></div>}
            </h3>
            <div className="bg-gray-50 rounded-lg p-3 h-40 overflow-y-auto text-sm text-gray-700">
              {transcript ||
                (speechSupported
                  ? "Start speaking to see live transcription..."
                  : "Speech recognition not supported in this browser")}
            </div>
          </div>

          {/* Navigation */}
          <div className="p-6 border-t border-gray-200">
            <div className="flex space-x-2">
              <Button onClick={nextQuestion} disabled={currentQuestion >= questions.length - 1} className="flex-1">
                {currentQuestion >= questions.length - 1 ? "Complete Interview" : "Next Question"}
              </Button>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
