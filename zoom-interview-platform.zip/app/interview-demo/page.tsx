"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import {
  Mic,
  MicOff,
  Video,
  VideoOff,
  Phone,
  Settings,
  Users,
  Star,
  Clock,
  MessageSquare,
  Award,
  Volume2,
  CheckCircle,
} from "lucide-react"

const interviewScript = [
  {
    time: 0,
    speaker: "interviewer",
    text: "Hello Sarah, thank you for joining us today. I'm excited to learn more about your background.",
  },
  {
    time: 3000,
    speaker: "candidate",
    text: "Thank you for having me! I'm really excited about this opportunity.",
  },
  {
    time: 6000,
    speaker: "interviewer",
    text: "Great! Let's start with our first question. Tell me about yourself and your background in software development.",
  },
  {
    time: 12000,
    speaker: "candidate",
    text: "I'm a passionate software developer with over 5 years of experience in full-stack development. I started my journey with JavaScript and React, and have since expanded my skills to include Node.js, Python, and cloud technologies like AWS.",
  },
  {
    time: 25000,
    speaker: "candidate",
    text: "In my current role at TechCorp, I lead a team of 4 developers working on e-commerce platforms. I've been responsible for architecting scalable solutions that handle over 100,000 daily active users. What I love most about development is solving complex problems and seeing the direct impact of my work on user experience.",
  },
  {
    time: 45000,
    speaker: "interviewer",
    text: "That's impressive! Can you tell me more about a specific challenging project you worked on?",
  },
  {
    time: 50000,
    speaker: "candidate",
    text: "One of the most challenging projects was when we had to migrate our entire payment system to a new provider while maintaining zero downtime. The challenge was that we had millions of transactions daily and couldn't afford any service interruption.",
  },
  {
    time: 65000,
    speaker: "candidate",
    text: "I approached this by implementing a gradual rollout strategy. First, I created a comprehensive testing environment that mirrored our production setup. Then I developed a feature flag system that allowed us to route a small percentage of traffic to the new system while monitoring performance metrics in real-time.",
  },
  {
    time: 85000,
    speaker: "candidate",
    text: "The most critical part was building robust error handling and automatic fallback mechanisms. If the new system showed any signs of issues, it would automatically route traffic back to the old system. This took about 3 months to complete, but we successfully migrated without a single minute of downtime.",
  },
  {
    time: 105000,
    speaker: "interviewer",
    text: "Excellent problem-solving approach! How do you stay updated with the latest technology trends?",
  },
  {
    time: 110000,
    speaker: "candidate",
    text: "I'm very committed to continuous learning. I follow several tech blogs like Hacker News and Dev.to, and I'm active in developer communities on Discord and Reddit. I also take online courses on platforms like Pluralsight and Udemy to dive deep into new technologies.",
  },
  {
    time: 125000,
    speaker: "candidate",
    text: "Recently, I've been exploring AI and machine learning integration in web applications. I completed a course on TensorFlow.js and built a small project that uses machine learning for image recognition in our product catalog. I believe staying curious and hands-on with new technologies is crucial in our field.",
  },
]

const questions = [
  {
    id: 1,
    question: "Tell me about yourself and your background in software development.",
    category: "Introduction",
    expectedDuration: 120,
    rubric: [
      "Clearly articulates professional background",
      "Mentions relevant experience and skills",
      "Shows enthusiasm and confidence",
      "Provides specific examples",
      "Demonstrates good communication skills",
    ],
  },
  {
    id: 2,
    question: "Describe a challenging project you worked on and how you overcame the obstacles.",
    category: "Problem Solving",
    expectedDuration: 180,
    rubric: [
      "Identifies a genuinely challenging situation",
      "Explains the problem clearly",
      "Describes specific actions taken",
      "Shows analytical thinking",
      "Demonstrates learning from experience",
    ],
  },
  {
    id: 3,
    question: "How do you stay updated with the latest technology trends?",
    category: "Learning & Growth",
    expectedDuration: 90,
    rubric: [
      "Shows commitment to continuous learning",
      "Mentions specific resources or methods",
      "Demonstrates curiosity about technology",
      "Explains how they apply new knowledge",
      "Shows awareness of industry trends",
    ],
  },
]

export default function InterviewDemoPage() {
  const [currentQuestion, setCurrentQuestion] = useState(0)
  const [isRecording, setIsRecording] = useState(false)
  const [videoEnabled, setVideoEnabled] = useState(true)
  const [audioEnabled, setAudioEnabled] = useState(true)
  const [timeElapsed, setTimeElapsed] = useState(0)
  const [transcript, setTranscript] = useState("")
  const [currentSpeaker, setCurrentSpeaker] = useState<"interviewer" | "candidate" | null>(null)
  const [demoStarted, setDemoStarted] = useState(false)
  const [scores, setScores] = useState({
    communication: 0,
    technical: 0,
    problemSolving: 0,
    culturalFit: 0,
  })
  const [overallScore, setOverallScore] = useState(0)
  const [checkedRubrics, setCheckedRubrics] = useState<{ [key: number]: boolean[] }>({})

  // Initialize rubrics
  useEffect(() => {
    const initialRubrics: { [key: number]: boolean[] } = {}
    questions.forEach((q) => {
      initialRubrics[q.id] = new Array(q.rubric.length).fill(false)
    })
    setCheckedRubrics(initialRubrics)
  }, [])

  // Demo script player
  useEffect(() => {
    if (!demoStarted) return

    const scriptTimeouts: NodeJS.Timeout[] = []

    interviewScript.forEach((item) => {
      const timeout = setTimeout(() => {
        if (item.speaker === "candidate") {
          setCurrentSpeaker("candidate")
          setTranscript((prev) => prev + item.text + " ")
        } else {
          setCurrentSpeaker("interviewer")
        }
      }, item.time)
      scriptTimeouts.push(timeout)
    })

    // Auto-advance questions
    const questionTimeouts = [
      setTimeout(() => setCurrentQuestion(0), 12000),
      setTimeout(() => setCurrentQuestion(1), 45000),
      setTimeout(() => setCurrentQuestion(2), 105000),
    ]

    return () => {
      scriptTimeouts.forEach(clearTimeout)
      questionTimeouts.forEach(clearTimeout)
    }
  }, [demoStarted])

  // Auto-evaluate based on transcript
  useEffect(() => {
    if (transcript) {
      const words = transcript.toLowerCase()

      // Update scores based on content
      const newScores = {
        communication: Math.min(95, 60 + words.split(" ").length * 0.1),
        technical: words.includes("javascript") || words.includes("react") || words.includes("node") ? 88 : 45,
        problemSolving:
          words.includes("challenge") || words.includes("problem") || words.includes("solution") ? 92 : 50,
        culturalFit: words.includes("team") || words.includes("passionate") || words.includes("learn") ? 90 : 55,
      }

      setScores(newScores)

      // Calculate overall score
      const overall =
        newScores.communication * 0.25 +
        newScores.technical * 0.3 +
        newScores.problemSolving * 0.25 +
        newScores.culturalFit * 0.2
      setOverallScore(Math.round(overall))

      // Auto-check rubrics
      const questionId = questions[currentQuestion]?.id
      if (questionId && checkedRubrics[questionId]) {
        const newChecked = [...checkedRubrics[questionId]]
        let hasChanges = false

        if (questionId === 1) {
          if (!newChecked[0] && (words.includes("experience") || words.includes("background"))) {
            newChecked[0] = true
            hasChanges = true
          }
          if (!newChecked[1] && (words.includes("javascript") || words.includes("react"))) {
            newChecked[1] = true
            hasChanges = true
          }
          if (!newChecked[2] && (words.includes("passionate") || words.includes("excited"))) {
            newChecked[2] = true
            hasChanges = true
          }
          if (!newChecked[3] && words.includes("techcorp")) {
            newChecked[3] = true
            hasChanges = true
          }
          if (!newChecked[4] && words.split(" ").length > 50) {
            newChecked[4] = true
            hasChanges = true
          }
        } else if (questionId === 2) {
          if (!newChecked[0] && words.includes("challenging")) {
            newChecked[0] = true
            hasChanges = true
          }
          if (!newChecked[1] && words.includes("payment system")) {
            newChecked[1] = true
            hasChanges = true
          }
          if (!newChecked[2] && words.includes("gradual rollout")) {
            newChecked[2] = true
            hasChanges = true
          }
          if (!newChecked[3] && words.includes("feature flag")) {
            newChecked[3] = true
            hasChanges = true
          }
          if (!newChecked[4] && words.includes("3 months")) {
            newChecked[4] = true
            hasChanges = true
          }
        } else if (questionId === 3) {
          if (!newChecked[0] && words.includes("continuous learning")) {
            newChecked[0] = true
            hasChanges = true
          }
          if (!newChecked[1] && (words.includes("pluralsight") || words.includes("udemy"))) {
            newChecked[1] = true
            hasChanges = true
          }
          if (!newChecked[2] && words.includes("curious")) {
            newChecked[2] = true
            hasChanges = true
          }
          if (!newChecked[3] && words.includes("tensorflow")) {
            newChecked[3] = true
            hasChanges = true
          }
          if (!newChecked[4] && words.includes("machine learning")) {
            newChecked[4] = true
            hasChanges = true
          }
        }

        if (hasChanges) {
          setCheckedRubrics((prev) => ({
            ...prev,
            [questionId]: newChecked,
          }))
        }
      }
    }
  }, [transcript, currentQuestion])

  // Timer
  useEffect(() => {
    if (demoStarted) {
      const interval = setInterval(() => {
        setTimeElapsed((prev) => prev + 1)
      }, 1000)
      return () => clearInterval(interval)
    }
  }, [demoStarted])

  const startDemo = () => {
    setDemoStarted(true)
    setIsRecording(true)
  }

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60)
    const secs = seconds % 60
    return `${mins}:${secs.toString().padStart(2, "0")}`
  }

  const currentQuestionData = questions[currentQuestion]
  const currentRubrics = checkedRubrics[currentQuestionData?.id] || []

  return (
    <div className="min-h-screen bg-gray-100">
      {/* Header */}
      <header className="bg-white border-b border-gray-200 px-6 py-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <div className="h-8 w-8 bg-blue-600 rounded-lg flex items-center justify-center">
              <span className="text-white font-bold text-sm">AI</span>
            </div>
            <span className="text-xl font-bold text-gray-900">InterviewPro</span>
          </div>
          <div className="flex items-center space-x-4">
            <Badge variant="secondary" className="bg-green-100 text-green-800">
              <div className="w-2 h-2 bg-green-500 rounded-full mr-2 animate-pulse"></div>
              Live Interview
            </Badge>
            <Badge variant="outline" className="bg-blue-50 text-blue-700">
              <Volume2 className="w-3 h-3 mr-1" />
              Speech Recognition Active
            </Badge>
            <div className="text-sm text-gray-600">
              Question {currentQuestion + 1} of {questions.length}
            </div>
          </div>
        </div>
      </header>

      <div className="flex h-[calc(100vh-80px)]">
        {/* Main Video Area */}
        <div className="flex-1 flex flex-col">
          {/* Video Container */}
          <div className="flex-1 bg-gray-900 relative">
            {/* Candidate Video (Main) */}
            <div className="w-full h-full bg-gradient-to-br from-blue-900 to-purple-900 flex items-center justify-center">
              {!demoStarted ? (
                <div className="text-center">
                  <div className="w-32 h-32 bg-blue-600 rounded-full flex items-center justify-center mx-auto mb-6">
                    <Users className="w-16 h-16 text-white" />
                  </div>
                  <h2 className="text-white text-2xl font-bold mb-4">Live Interview Demo</h2>
                  <p className="text-blue-200 mb-6">Watch Sarah Johnson's interview in real-time</p>
                  <Button onClick={startDemo} size="lg" className="bg-green-600 hover:bg-green-700">
                    Start Interview
                  </Button>
                </div>
              ) : (
                <div className="text-center">
                  <div
                    className={`w-32 h-32 rounded-full flex items-center justify-center mx-auto mb-4 transition-all duration-500 ${
                      currentSpeaker === "candidate" ? "bg-green-600 scale-110" : "bg-blue-600"
                    }`}
                  >
                    <Users className="w-16 h-16 text-white" />
                  </div>
                  <p className="text-white text-lg">Sarah Johnson</p>
                  <p className="text-blue-200 text-sm">Senior Frontend Developer</p>
                  {currentSpeaker === "candidate" && (
                    <div className="mt-4 flex items-center justify-center">
                      <div className="flex space-x-1">
                        <div className="w-2 h-2 bg-green-400 rounded-full animate-bounce"></div>
                        <div
                          className="w-2 h-2 bg-green-400 rounded-full animate-bounce"
                          style={{ animationDelay: "0.1s" }}
                        ></div>
                        <div
                          className="w-2 h-2 bg-green-400 rounded-full animate-bounce"
                          style={{ animationDelay: "0.2s" }}
                        ></div>
                      </div>
                      <span className="text-green-400 text-sm ml-2">Speaking...</span>
                    </div>
                  )}
                </div>
              )}
            </div>

            {/* Interviewer Video (Picture-in-Picture) */}
            <div className="absolute top-4 right-4 w-48 h-36 bg-gray-800 rounded-lg border-2 border-white shadow-lg">
              <div className="w-full h-full bg-gradient-to-br from-gray-700 to-gray-800 rounded-lg flex items-center justify-center">
                <div className="text-center">
                  <div
                    className={`w-12 h-12 rounded-full flex items-center justify-center mx-auto mb-2 transition-all duration-500 ${
                      currentSpeaker === "interviewer" ? "bg-purple-600 scale-110" : "bg-gray-600"
                    }`}
                  >
                    <Users className="w-6 h-6 text-white" />
                  </div>
                  <p className="text-white text-xs">Alex Chen</p>
                  <p className="text-gray-300 text-xs">Senior Hiring Manager</p>
                  {currentSpeaker === "interviewer" && (
                    <div className="mt-1 flex items-center justify-center">
                      <div className="w-1 h-1 bg-purple-400 rounded-full animate-pulse"></div>
                      <span className="text-purple-400 text-xs ml-1">Speaking</span>
                    </div>
                  )}
                </div>
              </div>
            </div>

            {/* Recording Indicator */}
            {isRecording && (
              <div className="absolute top-4 left-4 bg-red-600 text-white px-3 py-1 rounded-full text-sm flex items-center">
                <div className="w-2 h-2 bg-white rounded-full mr-2 animate-pulse"></div>
                REC {formatTime(timeElapsed)}
              </div>
            )}

            {/* AI Evaluation Overlay */}
            <div className="absolute bottom-4 left-4 bg-black/70 backdrop-blur-sm rounded-lg p-3 text-white">
              <div className="flex items-center space-x-2 mb-2">
                <Award className="w-4 h-4 text-yellow-400" />
                <span className="text-sm font-medium">AI Evaluation</span>
              </div>
              <div className="text-2xl font-bold text-green-400">{overallScore}%</div>
              <div className="text-xs text-gray-300">Real-time Score</div>
            </div>

            {/* Live Rubric Checking Indicator */}
            {demoStarted && (
              <div className="absolute bottom-4 right-4 bg-green-600/90 backdrop-blur-sm rounded-lg p-3 text-white">
                <div className="flex items-center space-x-2 mb-1">
                  <CheckCircle className="w-4 h-4" />
                  <span className="text-sm font-medium">Auto-Evaluation</span>
                </div>
                <div className="text-xs">
                  {currentRubrics.filter(Boolean).length}/{currentRubrics.length} criteria met
                </div>
              </div>
            )}
          </div>

          {/* Controls */}
          <div className="bg-gray-800 px-6 py-4">
            <div className="flex items-center justify-center space-x-4">
              <Button
                variant={audioEnabled ? "secondary" : "destructive"}
                size="lg"
                onClick={() => setAudioEnabled(!audioEnabled)}
                className="rounded-full w-12 h-12 p-0"
                disabled={!demoStarted}
              >
                {audioEnabled ? <Mic className="w-5 h-5" /> : <MicOff className="w-5 h-5" />}
              </Button>

              <Button
                variant={videoEnabled ? "secondary" : "destructive"}
                size="lg"
                onClick={() => setVideoEnabled(!videoEnabled)}
                className="rounded-full w-12 h-12 p-0"
                disabled={!demoStarted}
              >
                {videoEnabled ? <Video className="w-5 h-5" /> : <VideoOff className="w-5 h-5" />}
              </Button>

              <Button variant="secondary" size="lg" className="rounded-full w-12 h-12 p-0" disabled={!demoStarted}>
                <Settings className="w-5 h-5" />
              </Button>

              <Button variant="destructive" size="lg" className="rounded-full w-12 h-12 p-0" disabled={!demoStarted}>
                <Phone className="w-5 h-5" />
              </Button>
            </div>
          </div>
        </div>

        {/* Right Sidebar */}
        <div className="w-96 bg-white border-l border-gray-200 flex flex-col">
          {/* Current Question */}
          <div className="p-6 border-b border-gray-200">
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-semibold text-gray-900">Current Question</h3>
              <Badge variant="outline">{currentQuestionData?.category}</Badge>
            </div>
            <p className="text-gray-700 mb-4">{currentQuestionData?.question}</p>
            <div className="flex items-center text-sm text-gray-500">
              <Clock className="w-4 h-4 mr-1" />
              Expected: {currentQuestionData?.expectedDuration}s | Elapsed: {formatTime(timeElapsed)}
            </div>
          </div>

          {/* Real-time Evaluation */}
          <div className="p-6 border-b border-gray-200">
            <h3 className="font-semibold text-gray-900 mb-4 flex items-center">
              <Star className="w-4 h-4 mr-2 text-yellow-500" />
              Live Evaluation
            </h3>
            <div className="space-y-3">
              <div>
                <div className="flex justify-between text-sm mb-1">
                  <span className="text-gray-600">Communication</span>
                  <span className="font-medium">{Math.round(scores.communication)}%</span>
                </div>
                <Progress value={scores.communication} className="h-2" />
              </div>
              <div>
                <div className="flex justify-between text-sm mb-1">
                  <span className="text-gray-600">Technical Knowledge</span>
                  <span className="font-medium">{Math.round(scores.technical)}%</span>
                </div>
                <Progress value={scores.technical} className="h-2" />
              </div>
              <div>
                <div className="flex justify-between text-sm mb-1">
                  <span className="text-gray-600">Problem Solving</span>
                  <span className="font-medium">{Math.round(scores.problemSolving)}%</span>
                </div>
                <Progress value={scores.problemSolving} className="h-2" />
              </div>
              <div>
                <div className="flex justify-between text-sm mb-1">
                  <span className="text-gray-600">Cultural Fit</span>
                  <span className="font-medium">{Math.round(scores.culturalFit)}%</span>
                </div>
                <Progress value={scores.culturalFit} className="h-2" />
              </div>
            </div>
            <div className="mt-4 p-3 bg-blue-50 rounded-lg">
              <div className="flex justify-between items-center">
                <span className="font-medium text-blue-900">Overall Score</span>
                <span className="text-2xl font-bold text-blue-600">{overallScore}%</span>
              </div>
            </div>
          </div>

          {/* Auto-Checked Rubrics */}
          <div className="p-6 border-b border-gray-200">
            <h3 className="font-semibold text-gray-900 mb-4 flex items-center">
              <CheckCircle className="w-4 h-4 mr-2 text-green-600" />
              Auto-Evaluation Rubric
            </h3>
            <div className="space-y-2">
              {currentQuestionData?.rubric.map((criteria, index) => (
                <div key={index} className="flex items-start space-x-2">
                  <div
                    className={`w-4 h-4 rounded border-2 flex items-center justify-center mt-0.5 ${
                      currentRubrics[index] ? "bg-green-600 border-green-600" : "border-gray-300"
                    }`}
                  >
                    {currentRubrics[index] && <CheckCircle className="w-3 h-3 text-white" />}
                  </div>
                  <span
                    className={`text-sm ${currentRubrics[index] ? "text-green-700 line-through" : "text-gray-700"}`}
                  >
                    {criteria}
                  </span>
                </div>
              ))}
            </div>
            <div className="mt-3 p-2 bg-gray-50 rounded text-xs text-gray-600">
              {currentRubrics.filter(Boolean).length} / {currentQuestionData?.rubric.length} criteria automatically
              detected
            </div>
          </div>

          {/* Live Transcript */}
          <div className="flex-1 p-6">
            <h3 className="font-semibold text-gray-900 mb-4 flex items-center">
              <MessageSquare className="w-4 h-4 mr-2" />
              Live Transcript
              {currentSpeaker === "candidate" && (
                <div className="ml-2 w-2 h-2 bg-red-500 rounded-full animate-pulse"></div>
              )}
            </h3>
            <div className="bg-gray-50 rounded-lg p-3 h-40 overflow-y-auto text-sm text-gray-700">
              {transcript || "Interview will begin shortly..."}
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
