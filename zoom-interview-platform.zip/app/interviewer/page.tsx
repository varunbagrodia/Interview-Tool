"use client"

import { useState, useEffect, useRef } from "react"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Checkbox } from "@/components/ui/checkbox"
import {
  Mic,
  MicOff,
  Video,
  VideoOff,
  Phone,
  Settings,
  Users,
  Star,
  Clock,
  MessageSquare,
  Award,
  ArrowLeft,
  CheckCircle,
  Lightbulb,
  Send,
  Volume2,
} from "lucide-react"
import Link from "next/link"

const questions = [
  {
    id: 1,
    question: "Tell me about yourself and your background in software development.",
    category: "Introduction",
    expectedDuration: 120,
    rubric: [
      "Clearly articulates professional background",
      "Mentions relevant experience and skills",
      "Shows enthusiasm and confidence",
      "Provides specific examples",
      "Demonstrates good communication skills",
    ],
  },
  {
    id: 2,
    question: "Describe a challenging project you worked on and how you overcame the obstacles.",
    category: "Problem Solving",
    expectedDuration: 180,
    rubric: [
      "Identifies a genuinely challenging situation",
      "Explains the problem clearly",
      "Describes specific actions taken",
      "Shows analytical thinking",
      "Demonstrates learning from experience",
    ],
  },
  {
    id: 3,
    question: "How do you stay updated with the latest technology trends?",
    category: "Learning & Growth",
    expectedDuration: 90,
    rubric: [
      "Shows commitment to continuous learning",
      "Mentions specific resources or methods",
      "Demonstrates curiosity about technology",
      "Explains how they apply new knowledge",
      "Shows awareness of industry trends",
    ],
  },
]

const suggestedHints = {
  1: [
    "Can you tell me more about your most recent role?",
    "What technologies have you worked with recently?",
    "What drew you to software development?",
    "Can you elaborate on your experience with [specific technology]?",
  ],
  2: [
    "What made this project particularly challenging?",
    "How did you approach breaking down the problem?",
    "What would you do differently if you faced this again?",
    "How did you collaborate with your team during this challenge?",
  ],
  3: [
    "What's the most interesting technology you've learned recently?",
    "How do you decide which trends are worth investing time in?",
    "Can you give an example of how you applied something new you learned?",
    "What resources do you find most valuable for learning?",
  ],
}

export default function InterviewerPage() {
  const [currentQuestion, setCurrentQuestion] = useState(0)
  const [isRecording, setIsRecording] = useState(false)
  const [videoEnabled, setVideoEnabled] = useState(true)
  const [audioEnabled, setAudioEnabled] = useState(true)
  const [timeElapsed, setTimeElapsed] = useState(0)
  const [transcript, setTranscript] = useState("")
  const [checkedRubrics, setCheckedRubrics] = useState<{ [key: number]: boolean[] }>({})
  const [hintsGiven, setHintsGiven] = useState<{ [key: number]: string[] }>({})
  const [speechSupported, setSpeechSupported] = useState(false)
  const [overallScore, setOverallScore] = useState(0)
  const recognitionRef = useRef<any>(null)

  // Initialize rubric checkboxes
  useEffect(() => {
    const initialRubrics: { [key: number]: boolean[] } = {}
    questions.forEach((q) => {
      initialRubrics[q.id] = new Array(q.rubric.length).fill(false)
    })
    setCheckedRubrics(initialRubrics)
  }, []) // Empty dependency array since questions is static

  // Speech recognition setup
  useEffect(() => {
    if (typeof window !== "undefined") {
      const SpeechRecognition = window.SpeechRecognition || (window as any).webkitSpeechRecognition
      if (SpeechRecognition) {
        setSpeechSupported(true)
        recognitionRef.current = new SpeechRecognition()
        recognitionRef.current.continuous = true
        recognitionRef.current.interimResults = true
        recognitionRef.current.lang = "en-US"

        recognitionRef.current.onresult = (event: any) => {
          let finalTranscript = ""
          for (let i = event.resultIndex; i < event.results.length; i++) {
            if (event.results[i].isFinal) {
              finalTranscript += event.results[i][0].transcript + " "
            }
          }
          if (finalTranscript) {
            setTranscript((prev) => prev + finalTranscript)
          }
        }
      }
    }
  }, [])

  // Auto-evaluate rubrics based on transcript
  useEffect(() => {
    if (transcript && currentQuestion < questions.length) {
      const words = transcript.toLowerCase()
      const questionId = questions[currentQuestion].id
      const currentRubric = checkedRubrics[questionId]

      if (!currentRubric) return // Wait for rubrics to be initialized

      const newChecked = [...currentRubric]
      let hasChanges = false

      // Auto-check rubrics based on keywords
      if (questionId === 1) {
        // Introduction question
        if (!newChecked[0] && (words.includes("experience") || words.includes("background"))) {
          newChecked[0] = true
          hasChanges = true
        }
        if (!newChecked[1] && (words.includes("skill") || words.includes("technology"))) {
          newChecked[1] = true
          hasChanges = true
        }
        if (!newChecked[2] && (words.includes("passionate") || words.includes("love") || words.includes("enjoy"))) {
          newChecked[2] = true
          hasChanges = true
        }
        if (!newChecked[3] && (words.includes("project") || words.includes("worked on"))) {
          newChecked[3] = true
          hasChanges = true
        }
        if (!newChecked[4] && words.length > 50) {
          newChecked[4] = true
          hasChanges = true
        }
      } else if (questionId === 2) {
        // Problem solving
        if (!newChecked[0] && (words.includes("challenge") || words.includes("difficult"))) {
          newChecked[0] = true
          hasChanges = true
        }
        if (!newChecked[1] && (words.includes("problem") || words.includes("issue"))) {
          newChecked[1] = true
          hasChanges = true
        }
        if (!newChecked[2] && (words.includes("solution") || words.includes("approach"))) {
          newChecked[2] = true
          hasChanges = true
        }
        if (!newChecked[3] && (words.includes("analyze") || words.includes("think"))) {
          newChecked[3] = true
          hasChanges = true
        }
        if (!newChecked[4] && (words.includes("learn") || words.includes("next time"))) {
          newChecked[4] = true
          hasChanges = true
        }
      } else if (questionId === 3) {
        // Learning
        if (!newChecked[0] && (words.includes("learn") || words.includes("study"))) {
          newChecked[0] = true
          hasChanges = true
        }
        if (!newChecked[1] && (words.includes("blog") || words.includes("course") || words.includes("documentation"))) {
          newChecked[1] = true
          hasChanges = true
        }
        if (!newChecked[2] && (words.includes("curious") || words.includes("interested"))) {
          newChecked[2] = true
          hasChanges = true
        }
        if (!newChecked[3] && (words.includes("apply") || words.includes("use"))) {
          newChecked[3] = true
          hasChanges = true
        }
        if (!newChecked[4] && (words.includes("trend") || words.includes("new"))) {
          newChecked[4] = true
          hasChanges = true
        }
      }

      // Only update if there are actual changes
      if (hasChanges) {
        setCheckedRubrics((prev) => ({
          ...prev,
          [questionId]: newChecked,
        }))
      }
    }
  }, [transcript, currentQuestion]) // Removed checkedRubrics from dependencies

  // Separate useEffect for calculating overall score
  useEffect(() => {
    const totalChecked = Object.values(checkedRubrics).flat().filter(Boolean).length
    const totalRubrics = questions.reduce((sum, q) => sum + q.rubric.length, 0)
    const newScore = totalRubrics > 0 ? Math.round((totalChecked / totalRubrics) * 100) : 0

    if (newScore !== overallScore) {
      setOverallScore(newScore)
    }
  }, [checkedRubrics, overallScore])

  // Timer
  useEffect(() => {
    if (isRecording) {
      const interval = setInterval(() => {
        setTimeElapsed((prev) => prev + 1)
      }, 1000)
      return () => clearInterval(interval)
    }
  }, [isRecording])

  const startRecording = () => {
    setIsRecording(true)
    setTimeElapsed(0)
    if (speechSupported && recognitionRef.current) {
      recognitionRef.current.start()
    }
  }

  const stopRecording = () => {
    setIsRecording(false)
    if (speechSupported && recognitionRef.current) {
      recognitionRef.current.stop()
    }
  }

  const toggleRubric = (questionId: number, index: number) => {
    setCheckedRubrics((prev) => ({
      ...prev,
      [questionId]: prev[questionId]?.map((checked, i) => (i === index ? !checked : checked)) || [],
    }))
  }

  const giveHint = (hint: string) => {
    const questionId = questions[currentQuestion].id
    setHintsGiven((prev) => ({
      ...prev,
      [questionId]: [...(prev[questionId] || []), hint],
    }))
  }

  const nextQuestion = () => {
    if (currentQuestion < questions.length - 1) {
      setCurrentQuestion((prev) => prev + 1)
      setTranscript("")
      setTimeElapsed(0)
    }
  }

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60)
    const secs = seconds % 60
    return `${mins}:${secs.toString().padStart(2, "0")}`
  }

  const currentQuestionData = questions[currentQuestion]
  const currentRubrics = checkedRubrics[currentQuestionData?.id] || []
  const currentHints = hintsGiven[currentQuestionData?.id] || []

  return (
    <div className="min-h-screen bg-gray-100">
      {/* Header */}
      <header className="bg-white border-b border-gray-200 px-6 py-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <Link href="/">
              <Button variant="ghost" size="sm">
                <ArrowLeft className="w-4 h-4 mr-2" />
                Back to Home
              </Button>
            </Link>
            <div className="flex items-center space-x-2">
              <div className="h-8 w-8 bg-purple-600 rounded-lg flex items-center justify-center">
                <span className="text-white font-bold text-sm">HR</span>
              </div>
              <span className="text-xl font-bold text-gray-900">Hiring Manager Dashboard</span>
            </div>
          </div>
          <div className="flex items-center space-x-4">
            <Badge variant="secondary" className="bg-purple-100 text-purple-800">
              <Award className="w-3 h-3 mr-1" />
              AI-Assisted Interview
            </Badge>
            <Badge variant="outline" className="bg-green-50 text-green-700">
              Standardized Process
            </Badge>
            <div className="text-sm text-gray-600">
              Question {currentQuestion + 1} of {questions.length}
            </div>
          </div>
        </div>
      </header>

      <div className="flex h-[calc(100vh-80px)]">
        {/* Main Video Area */}
        <div className="flex-1 flex flex-col">
          {/* Video Container */}
          <div className="flex-1 bg-gray-900 relative">
            {/* Candidate Video (Main) */}
            <div className="w-full h-full bg-gradient-to-br from-blue-900 to-purple-900 flex items-center justify-center">
              <div className="text-center">
                <div className="w-32 h-32 bg-blue-600 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Users className="w-16 h-16 text-white" />
                </div>
                <p className="text-white text-lg">Candidate: Sarah Johnson</p>
                <p className="text-blue-200 text-sm">Senior Frontend Developer</p>
              </div>
            </div>

            {/* Recording Indicator */}
            {isRecording && (
              <div className="absolute top-4 left-4 bg-red-600 text-white px-3 py-1 rounded-full text-sm flex items-center">
                <div className="w-2 h-2 bg-white rounded-full mr-2 animate-pulse"></div>
                REC {formatTime(timeElapsed)}
              </div>
            )}

            {/* AI Status */}
            <div className="absolute top-4 right-4 bg-green-600 text-white px-3 py-1 rounded-full text-sm flex items-center">
              <CheckCircle className="w-3 h-3 mr-2" />
              AI Evaluation Active
            </div>

            {/* Overall Score Display */}
            <div className="absolute bottom-4 left-4 bg-black/70 backdrop-blur-sm rounded-lg p-4 text-white">
              <div className="flex items-center space-x-2 mb-2">
                <Star className="w-5 h-5 text-yellow-400" />
                <span className="font-medium">Interview Score</span>
              </div>
              <div className="text-3xl font-bold text-green-400">{overallScore}%</div>
              <div className="text-xs text-gray-300">
                {Object.values(checkedRubrics).flat().filter(Boolean).length} /{" "}
                {questions.reduce((sum, q) => sum + q.rubric.length, 0)} criteria met
              </div>
            </div>
          </div>

          {/* Controls */}
          <div className="bg-gray-800 px-6 py-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-4">
                <Button
                  variant={audioEnabled ? "secondary" : "destructive"}
                  size="lg"
                  onClick={() => setAudioEnabled(!audioEnabled)}
                  className="rounded-full w-12 h-12 p-0"
                >
                  {audioEnabled ? <Mic className="w-5 h-5" /> : <MicOff className="w-5 h-5" />}
                </Button>

                <Button
                  variant={videoEnabled ? "secondary" : "destructive"}
                  size="lg"
                  onClick={() => setVideoEnabled(!videoEnabled)}
                  className="rounded-full w-12 h-12 p-0"
                >
                  {videoEnabled ? <Video className="w-5 h-5" /> : <VideoOff className="w-5 h-5" />}
                </Button>

                {!isRecording ? (
                  <Button onClick={startRecording} className="bg-green-600 hover:bg-green-700 px-6" size="lg">
                    Start Question
                  </Button>
                ) : (
                  <Button onClick={stopRecording} variant="destructive" className="px-6" size="lg">
                    Stop Question
                  </Button>
                )}
              </div>

              <div className="flex items-center space-x-4">
                <Button onClick={nextQuestion} disabled={currentQuestion >= questions.length - 1} className="px-6">
                  {currentQuestion >= questions.length - 1 ? "Complete Interview" : "Next Question"}
                </Button>

                <Button variant="secondary" size="lg" className="rounded-full w-12 h-12 p-0">
                  <Settings className="w-5 h-5" />
                </Button>

                <Button variant="destructive" size="lg" className="rounded-full w-12 h-12 p-0">
                  <Phone className="w-5 h-5" />
                </Button>
              </div>
            </div>
          </div>
        </div>

        {/* Right Sidebar - Evaluation Panel */}
        <div className="w-96 bg-white border-l border-gray-200 flex flex-col overflow-hidden">
          {/* Current Question */}
          <div className="p-4 border-b border-gray-200">
            <div className="flex items-center justify-between mb-3">
              <h3 className="font-semibold text-gray-900">Current Question</h3>
              <Badge variant="outline">{currentQuestionData?.category}</Badge>
            </div>
            <p className="text-gray-700 text-sm mb-3">{currentQuestionData?.question}</p>
            <div className="flex items-center text-xs text-gray-500">
              <Clock className="w-3 h-3 mr-1" />
              Expected: {currentQuestionData?.expectedDuration}s | Elapsed: {formatTime(timeElapsed)}
            </div>
          </div>

          {/* Evaluation Rubric */}
          <div className="p-4 border-b border-gray-200">
            <h3 className="font-semibold text-gray-900 mb-3 flex items-center">
              <CheckCircle className="w-4 h-4 mr-2 text-green-600" />
              Evaluation Rubric
            </h3>
            <div className="space-y-2">
              {currentQuestionData?.rubric.map((criteria, index) => (
                <div key={index} className="flex items-start space-x-2">
                  <Checkbox
                    id={`rubric-${index}`}
                    checked={currentRubrics[index] || false}
                    onCheckedChange={() => toggleRubric(currentQuestionData.id, index)}
                    className="mt-1"
                  />
                  <label
                    htmlFor={`rubric-${index}`}
                    className={`text-sm cursor-pointer ${
                      currentRubrics[index] ? "text-green-700 line-through" : "text-gray-700"
                    }`}
                  >
                    {criteria}
                  </label>
                </div>
              ))}
            </div>
            <div className="mt-3 p-2 bg-gray-50 rounded text-xs text-gray-600">
              {currentRubrics.filter(Boolean).length} / {currentQuestionData?.rubric.length} criteria met
            </div>
          </div>

          {/* Suggested Hints */}
          <div className="p-4 border-b border-gray-200">
            <h3 className="font-semibold text-gray-900 mb-3 flex items-center">
              <Lightbulb className="w-4 h-4 mr-2 text-yellow-600" />
              Suggested Hints
            </h3>
            <div className="space-y-2">
              {suggestedHints[currentQuestionData?.id as keyof typeof suggestedHints]?.map((hint, index) => (
                <div key={index} className="flex items-center justify-between p-2 bg-yellow-50 rounded text-sm">
                  <span className="text-gray-700 flex-1">{hint}</span>
                  <Button
                    size="sm"
                    variant="ghost"
                    onClick={() => giveHint(hint)}
                    className="ml-2 h-6 w-6 p-0"
                    disabled={currentHints.includes(hint)}
                  >
                    <Send className="w-3 h-3" />
                  </Button>
                </div>
              ))}
            </div>
          </div>

          {/* Hints Given */}
          {currentHints.length > 0 && (
            <div className="p-4 border-b border-gray-200">
              <h3 className="font-semibold text-gray-900 mb-3 flex items-center">
                <MessageSquare className="w-4 h-4 mr-2 text-blue-600" />
                Hints Given ({currentHints.length})
              </h3>
              <div className="space-y-1">
                {currentHints.map((hint, index) => (
                  <div key={index} className="text-xs text-blue-700 bg-blue-50 p-2 rounded">
                    ✓ {hint}
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Live Transcript */}
          <div className="flex-1 p-4 overflow-hidden">
            <h3 className="font-semibold text-gray-900 mb-3 flex items-center">
              <Volume2 className="w-4 h-4 mr-2" />
              Live Transcript
            </h3>
            <div className="bg-gray-50 rounded-lg p-3 h-full overflow-y-auto text-sm text-gray-700">
              {transcript || "Waiting for candidate response..."}
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
